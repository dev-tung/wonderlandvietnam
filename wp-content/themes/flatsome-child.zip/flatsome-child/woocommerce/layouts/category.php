<?php echo do_shortcode('[buildings_search]'); ?>
